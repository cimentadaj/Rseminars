# Code placed in this file fill be executed every time the
# lesson is started. Any variables created here will show up in
# the user's working directory and thus be accessible to them
# throughout the lesson.

dataset1 <- data.frame(first=1:10,second=sample(letters,10,replace = T))
dataset2 <- data.frame(first=1:10,third=rep(c(1,2),each=5))

dataset3 <- data.frame(first=1:10, second=sample(letters,10,replace = T))
dataset4 <- data.frame(first=11:20, second=sample(letters,10,replace = T))
# Code placed in this file fill be executed every time the
# lesson is started. Any variables created here will show up in
# the user's working directory and thus be accessible to them
# throughout the lesson.

asfr7512 <- read.table("asfr752012ine1.csv", sep=",", header = TRUE)
asfr1314 <- read.table("asfr1314ine.txt", sep="",header= TRUE)

even <- seq(2,40,2)

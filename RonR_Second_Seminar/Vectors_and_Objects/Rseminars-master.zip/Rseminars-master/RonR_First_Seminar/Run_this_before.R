install.packages("devtools")
library(devtools)
source_url("https://raw.githubusercontent.com/cimentadaj/Rseminars/master/RonR_First_Seminar/packages.R")
